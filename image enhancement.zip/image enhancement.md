```python
from PIL import Image
from PIL import ImageEnhance
  
# Opens the image file
image = Image.open('gas1.jpg')  
  
# shows image in image viewer
image.show()  
  
  
# Enhance Brightness
curr_bri = ImageEnhance.Brightness(image)
new_bri = 2

  
# Brightness enhanced by a factor of 2.5
img_brightened = curr_bri.enhance(new_bri)

  
# shows updated image in image viewer
img_brightened.show()  

```


```python
import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt
```


```python
#path = "E:\Girl.jpg"
img = cv.imread('Girl.jpg')
#img = cv2.imread(path)
```


```python
cv.imshow('image',img)
cv.waitKey()
cv.destroyAllWindows()
```


```python
hist,bins = np.histogram(img.flatten(),256,[0,256])
cdf = hist.cumsum()
cdf_normalized = cdf * float(hist.max()) / cdf.max()
plt.plot(cdf_normalized, color = 'b')
plt.hist(img.flatten(),256,[0,256], color = 'r')
plt.xlim([0,256])
plt.legend(('cdf','histogram'), loc = 'upper left')
plt.show()
```


    
![png](output_4_0.png)
    



```python
equ = cv.equalizeHist(img)
```


    ---------------------------------------------------------------------------

    error                                     Traceback (most recent call last)

    <ipython-input-64-512a660dbb2b> in <module>
    ----> 1 equ = cv.equalizeHist(img)
    

    error: OpenCV(4.0.1) C:\ci\opencv-suite_1573470242804\work\modules\imgproc\src\histogram.cpp:3345: error: (-215:Assertion failed) _src.type() == CV_8UC1 in function 'cv::equalizeHist'
    



```python
cv.imshow('equ.png',equ)
cv.waitKey(0)
cv.destroyAllWindows()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-65-811c0e3d3c94> in <module>
    ----> 1 cv.imshow('equ.png',equ)
          2 cv.waitKey(0)
          3 cv.destroyAllWindows()
    

    NameError: name 'equ' is not defined



```python

```
